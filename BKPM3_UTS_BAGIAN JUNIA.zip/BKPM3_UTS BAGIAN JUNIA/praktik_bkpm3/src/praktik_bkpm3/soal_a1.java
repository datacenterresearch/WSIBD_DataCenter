//Junia Vitasari (E41212161)
//Soal praktik A1
//Array

package praktik_bkpm3;
public class soal_a1 {
    public static void main(String[] args) {
     int []  angka = {3,7,8,1,10,20,35};
     
     System.out.println("Jumlah elemen array angka= " +angka.length);
    } 
}
