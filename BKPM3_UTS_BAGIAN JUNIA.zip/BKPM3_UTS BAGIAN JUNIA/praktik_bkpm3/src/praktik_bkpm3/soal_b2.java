//Soal praktik B2
package praktik_bkpm3;
import java.util.Scanner;
public class soal_b2 {
    public static void main(String[] args) {
        String lampu;
        Scanner datacenter = new Scanner(System.in);
        
        System.out.print("Inputkan nama warna: ");
        lampu = datacenter.nextLine();
        
        switch (lampu){
            case "merah":
                System.out.println("Lampu merah, berhenti!");
                break;
            case "kuning":
                System.out.println("Lampu kuning, harap berhati-hati");
                break;
            case "hijau":
                System.out.println("Lampu hijau, silahkan jalan");
                break;
            default:
                System.out.println("Warna lampu salah!");
        }
    } 
}
