//Soal tugas d

package tugas_bkpm3;
import  java.util.Scanner;
public class tugas_bkpm3_d {
    public static void main(String[] args) {
       String pembeli;
       String barang[]=new String[3];
       int harga[]=new int[3], total;
        Scanner data=new Scanner(System.in);
        Scanner center=new Scanner(System.in);
 
        String [] teks = {"===MIE GACOAN CABANG SIDOARJO===","PROMO BUY TWO GET ONE FREE","DENGAN TOTAL PEMBELIAN MINIMUM Rp 100.000"};
      
       for (int a=0; a<teks.length; a++){
            System.out.println(teks[a]);
            System.out.print(" ");}
          
        System.out.println("Nama pembelinya siapa nih?");
        pembeli=data.nextLine();
        
        System.out.println("Masukan harga pesanan ke-1 = ");
        harga[0]=center.nextInt();
        System.out.println("Masukan harga pesanan ke-2 = ");
        harga[1]=center.nextInt();
        System.out.println("Masukan harga pesanan ke-3 = ");
        harga[2]=center.nextInt();
        
        total=harga[0]+harga[1]+harga[2];
        System.out.println("Total pembelian" +" " +pembeli+ " " + "adalah " +total);
        
        if (total>=100000) {
            System.out.println("Selamat!! " +pembeli+ " mendapatkan free 1 paket gacoan (all varian bebas pilih)");
        }else{
            System.out.println("Maaf! total belanja " + pembeli+ " tidak mencapai minimum belanja.");
            System.out.println("Yuk tambah pesanananmu dan dapatkan 1 paket gratis all varian");
        }

    }
    
}
