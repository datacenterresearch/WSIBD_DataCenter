//Soal tugas a
package tugas_bkpm3;
public class Tugas_bkpm3 {
    public static void main(String[] args) {
      String [] teks = {"Sugito","Prayoga","Rahardika"};
      
       for (int a=0; a<teks.length; a++){
            System.out.print(teks[a]);
            System.out.print(" ");}
    } 
}
