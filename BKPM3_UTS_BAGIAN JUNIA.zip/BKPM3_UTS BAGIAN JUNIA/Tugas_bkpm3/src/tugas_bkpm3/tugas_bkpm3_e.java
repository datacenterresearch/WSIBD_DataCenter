//soal e

package tugas_bkpm3;
import java.util.Scanner;
public class tugas_bkpm3_e {
    public static void main(String[] args) {
       
        String pembeli;
        int item;
        Scanner sambal=new Scanner(System.in);
        Scanner geprek=new Scanner(System.in);
        String menu[]=new String[6];
        menu[0]="";
        menu[1]="Ayam geprek + Nasi + Es jeruk";
        menu[2]="Jamur geprek + Nasi + Es jeruk";
        menu[3]="Indomie goreng + Nasi + Sambal geprek";
        menu[4]="Tempe geprek + Nasi + Es teh";
        menu[5]="Tahu geprek + Nasi + Es teh";
        
       
        System.out.println("                   WARUNG BUK KOS                 ");
        System.out.println("        SEDIA BERBAGAI MENU PAKET ANAK KOS        ");
        System.out.println("===============================================================================");
        System.out.println("                    PAKET MENU                    ");
        String [] teks = {"1. Paket hedonnya anak kos (Ayam geprek + Nasi + Es jeruk)",
             "2. Paket hematnya anak kos (Jamur geprek + Nasi + Es jeruk)",
             "3. Paket makannya anak kos (Indomie goreng + Nasi + Sambal geprek)",
             "4. Paket tanggal tuanya anak kos (Tempe geprek + Nasi + Es teh)",
             "5. Paket tanggal tua vers.2 anak kos (Tahu geprek + Nasi + Es teh)",
         "==============================================================================="};
       for (int a=0; a<teks.length; a++){
            System.out.println(teks[a]);
            System.out.print("");}
       
        System.out.print("Siapa nih yang beli? ");
        pembeli = sambal.nextLine();
        System.out.print("Nomor paket menu yang kamu pesan berapa nih? ");
        item=geprek.nextInt();
        System.out.println(" ");
        switch (item) {
            case 1:
                System.out.println(pembeli +" "+"memesan"+" "+menu[1]);
                break;
            case 2:
                System.out.println(pembeli +" "+"mmemesan"+" "+menu[2]);
                break;
            case 3:
                System.out.println(pembeli +" "+"memesan"+" "+menu[3]);
                break;
            case 4:
                System.out.println(pembeli +" "+"memesan"+" "+menu[4]);
                break;
            case 5:
                System.out.println(pembeli +" "+"memesan"+" "+menu[5]);
                break;
            default:
                System.out.println("Tolong masukkan nomor paket dari angka 1-5 ya..");
                break;   
        }
            System.out.println("Pesanan akan segera Buk Kos antar");
            System.out.println("Terima Kasih "+pembeli+" ,telah mampir ke warung Buk Kos");
    }          
      }
    

