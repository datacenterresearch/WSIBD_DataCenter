//Soal tugas b
package tugas_bkpm3;
import java.util.Scanner;
public class tugas_bkpm3_b {
    public static void main(String[] args) {
        Scanner datacenter = new Scanner(System.in);
       int deretan = 0;
       
       System.out.print("masukkan jumlah deretnya disini: ");
       deretan = datacenter.nextInt();
       
       int[]deretan_random = new int [deretan];
       for(int i = 0; i < deretan ; i++){
           deretan_random[i]=(int)(Math.random()*10);
       } 
       for (int j = 0; j < deretan; j++){
           System.out.println(deretan_random[j]+"\t");
       }
    }  
}
