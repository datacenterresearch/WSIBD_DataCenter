package latihan2.tugas;
    class object{
       String fName = "Lisa Palombo";
       String IName = "Lisa";
       int stuId = 123456789;
       String stuStatus = "Active";
       
       void set(){
           System.out.println ("Student Name: " +fName);
           System.out.println("Student Nick Name: " +IName);
           System.out.println ("Student ID: " +stuId);
           System.out.println ("Student Status: " +stuStatus);
       }
    }
   public class tugasa {
       public static void main(String[] args) {      
           object object = new object();
           
           object.set();
    }  
}