package latihan2.tugas;

public class tugasc {
    boolean gameOver = false;
    int students=50,classes=3;
    double sales_tax;
    short number1;
    
    int 2beOrNot2be; // salah karena int tidak boleh diawali angka
    int beOrNot2be;  // benar karena tidak diawali angka pada int
    
    float price index; // salah karena tidak boleh ada spasi pada float
    float price_index; // benar karena menggunakan (_) sebagai pengganti spasi
    
    double lastYear'sPrice; 
    // salah karena menggunakan tanda petik (') 
    double lastYearPrice;
    // benar karena tidak menggunakan tanda petik
    
    long class; // salah karena tidak boleh menggunakan nama class
    long clas; // benar karena tidak menggunakan nama class
}