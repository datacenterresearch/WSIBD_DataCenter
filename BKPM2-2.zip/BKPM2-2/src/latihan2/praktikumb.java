package latihan2;

public class praktikumb {
    public static void main(String[] args) {
        String nama = "Indonesia";
        char abjad = 'a';
        int a = 6;
        double b = 6.9;
        
        System.out.println (nama);
        System.out.println (a);
    }
    
}
