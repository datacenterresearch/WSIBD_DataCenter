package latihan2;

public class praktikuma {
    public static void main(String[] args) {
    System.out.println("Hello ");
    System.out.println("World !");
    
    System.out.print("Hello ");
    System.out.print("World !");
}}
